Carson Murray Final Project CSCE 350 Fall 2022

To be clear, this project only contains a solution to Task 1. All other files associated with Task 2 are included but blank.

To Compile:
type "make all" into the command line

To Clean:
type "make clean" into the command line

To Run:
type "./Murray_Carson_QuickSort input.txt output.txt output2.txt" into the command line
Where: 
1. input.txt is an unsorted list of floating point numbers, seperated by blank spaces.
2. output.txt is the file you want the sorted list of floating point numbers seperated by blank spaces to populate.
3. output2.txt is the file you want the execution time (in miliseconds) to populate.

Note: Three files must be entered into the command line as arguments, in the correct order (shown above) for the program to execute properly.